package com.ctr.mocklocation.model

import com.google.gson.annotations.SerializedName

/**
 * A single waypoint in a route
 */
data class Waypoint(
    @SerializedName("lat")
    val latitude: Double,
    
    @SerializedName("lng")
    val longitude: Double,
    
    @SerializedName("elevation")
    val elevation: Double? = null,
    
    @SerializedName("timestamp")
    val timestamp: Long? = null,
    
    @SerializedName("name")
    val name: String? = null
)

/**
 * A route consisting of multiple waypoints
 */
data class Route(
    @SerializedName("id")
    val id: String,
    
    @SerializedName("name")
    val name: String,
    
    @SerializedName("waypoints")
    val waypoints: List<Waypoint>,
    
    @SerializedName("speed_kmh")
    val speedKmh: Float = 30f,
    
    @SerializedName("loop")
    val loop: Boolean = false
)

/**
 * Command received from server via WebSocket
 */
data class ServerCommand(
    @SerializedName("type")
    val type: String,
    
    @SerializedName("payload")
    val payload: Map<String, Any>? = null
) {
    companion object {
        const val TYPE_LOAD_ROUTE = "load_route"
        const val TYPE_START = "start"
        const val TYPE_STOP = "stop"
        const val TYPE_PAUSE = "pause"
        const val TYPE_RESUME = "resume"
        const val TYPE_SET_SPEED = "set_speed"
        const val TYPE_SET_LOCATION = "set_location"
        const val TYPE_PING = "ping"
    }
}

/**
 * Status update sent to server
 */
data class DeviceStatus(
    @SerializedName("device_id")
    val deviceId: String,
    
    @SerializedName("status")
    val status: String,
    
    @SerializedName("latitude")
    val latitude: Double?,
    
    @SerializedName("longitude")
    val longitude: Double?,
    
    @SerializedName("speed")
    val speed: Float?,
    
    @SerializedName("route_id")
    val routeId: String?,
    
    @SerializedName("progress")
    val progress: Float?,
    
    @SerializedName("timestamp")
    val timestamp: Long = System.currentTimeMillis()
) {
    companion object {
        const val STATUS_IDLE = "idle"
        const val STATUS_PLAYING = "playing"
        const val STATUS_PAUSED = "paused"
        const val STATUS_COMPLETED = "completed"
        const val STATUS_ERROR = "error"
    }
}

/**
 * Current playback state
 */
data class PlaybackState(
    val isPlaying: Boolean = false,
    val isPaused: Boolean = false,
    val currentRoute: Route? = null,
    val currentIndex: Int = 0,
    val currentWaypoint: Waypoint? = null,
    val speedMultiplier: Float = 1.0f
) {
    val progress: Float
        get() = if (currentRoute != null && currentRoute.waypoints.isNotEmpty()) {
            currentIndex.toFloat() / currentRoute.waypoints.size
        } else 0f
}
