package com.ctr.mocklocation.api

import android.util.Log
import com.ctr.mocklocation.model.DeviceStatus
import com.ctr.mocklocation.model.Route
import com.ctr.mocklocation.model.ServerCommand
import com.ctr.mocklocation.model.Waypoint
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * API client for server communication (REST + WebSocket)
 */
class ApiClient(
    private var serverUrl: String,
    private val deviceId: String
) {
    companion object {
        private const val TAG = "ApiClient"
        private const val RECONNECT_DELAY_MS = 5000L
        private const val PING_INTERVAL_MS = 30000L
    }
    
    private val gson = Gson()
    
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()
    
    private var webSocket: WebSocket? = null
    private var scope: CoroutineScope? = null
    private var pingJob: Job? = null
    private var autoReconnect = true
    
    // Connection state
    private val _isConnected = MutableStateFlow(false)
    val isConnected: StateFlow<Boolean> = _isConnected
    
    // Incoming commands from server
    private val _commands = MutableSharedFlow<ServerCommand>(extraBufferCapacity = 10)
    val commands: SharedFlow<ServerCommand> = _commands
    
    // Callbacks
    var onConnected: (() -> Unit)? = null
    var onDisconnected: (() -> Unit)? = null
    var onError: ((String) -> Unit)? = null
    
    /**
     * Update server URL
     */
    fun setServerUrl(url: String) {
        serverUrl = url.trimEnd('/')
    }
    
    // ========== REST API ==========
    
    /**
     * Fetch a route by ID from the server
     */
    suspend fun fetchRoute(routeId: String): Route? = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder()
                .url("$serverUrl/api/routes/$routeId")
                .header("X-Device-ID", deviceId)
                .get()
                .build()
            
            httpClient.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string()
                    body?.let { parseRoute(it) }
                } else {
                    Log.e(TAG, "Failed to fetch route: ${response.code}")
                    null
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching route", e)
            null
        }
    }
    
    /**
     * Send device status to server
     */
    fun sendStatus(status: DeviceStatus) {
        val json = gson.toJson(status)
        
        // Try WebSocket first
        if (_isConnected.value) {
            val message = gson.toJson(mapOf(
                "type" to "status",
                "data" to status
            ))
            webSocket?.send(message)
            return
        }
        
        // Fallback to REST
        val request = Request.Builder()
            .url("$serverUrl/api/devices/status")
            .header("X-Device-ID", deviceId)
            .post(json.toRequestBody("application/json".toMediaType()))
            .build()
        
        httpClient.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.w(TAG, "Failed to send status: ${e.message}")
            }
            override fun onResponse(call: Call, response: Response) {
                response.close()
            }
        })
    }
    
    /**
     * Register device with server
     */
    suspend fun registerDevice(): Boolean = withContext(Dispatchers.IO) {
        try {
            val data = mapOf(
                "device_id" to deviceId,
                "app_version" to "1.0.0",
                "timestamp" to System.currentTimeMillis()
            )
            
            val request = Request.Builder()
                .url("$serverUrl/api/devices/register")
                .header("X-Device-ID", deviceId)
                .post(gson.toJson(data).toRequestBody("application/json".toMediaType()))
                .build()
            
            httpClient.newCall(request).execute().use { response ->
                response.isSuccessful
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error registering device", e)
            false
        }
    }
    
    // ========== WebSocket ==========
    
    /**
     * Connect to WebSocket for real-time commands
     */
    fun connect() {
        if (_isConnected.value) {
            Log.d(TAG, "Already connected")
            return
        }
        
        autoReconnect = true
        scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
        
        val wsUrl = serverUrl.replace("http://", "ws://").replace("https://", "wss://")
        val request = Request.Builder()
            .url("$wsUrl/api/ws/$deviceId")
            .build()
        
        Log.d(TAG, "Connecting to WebSocket: $wsUrl/api/ws/$deviceId")
        
        webSocket = httpClient.newWebSocket(request, object : WebSocketListener() {
            
            override fun onOpen(webSocket: WebSocket, response: Response) {
                Log.i(TAG, "WebSocket connected")
                _isConnected.value = true
                onConnected?.invoke()
                startPing()
            }
            
            override fun onMessage(webSocket: WebSocket, text: String) {
                Log.d(TAG, "WebSocket message: $text")
                try {
                    val command = gson.fromJson(text, ServerCommand::class.java)
                    scope?.launch {
                        _commands.emit(command)
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Failed to parse command", e)
                }
            }
            
            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                Log.d(TAG, "WebSocket closing: $code $reason")
                webSocket.close(1000, null)
            }
            
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                Log.i(TAG, "WebSocket closed: $code $reason")
                handleDisconnect()
            }
            
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                Log.e(TAG, "WebSocket failure: ${t.message}")
                onError?.invoke(t.message ?: "Connection failed")
                handleDisconnect()
            }
        })
    }
    
    private fun handleDisconnect() {
        _isConnected.value = false
        pingJob?.cancel()
        onDisconnected?.invoke()
        
        // Auto reconnect
        if (autoReconnect) {
            scope?.launch {
                delay(RECONNECT_DELAY_MS)
                if (autoReconnect) {
                    Log.d(TAG, "Attempting to reconnect...")
                    connect()
                }
            }
        }
    }
    
    private fun startPing() {
        pingJob?.cancel()
        pingJob = scope?.launch {
            while (isActive && _isConnected.value) {
                delay(PING_INTERVAL_MS)
                val ping = gson.toJson(mapOf("type" to "ping", "device_id" to deviceId))
                webSocket?.send(ping)
            }
        }
    }
    
    /**
     * Send a message to server via WebSocket
     */
    fun sendMessage(type: String, data: Map<String, Any?> = emptyMap()) {
        if (!_isConnected.value) {
            Log.w(TAG, "Cannot send message - not connected")
            return
        }
        
        val message = gson.toJson(mapOf(
            "type" to type,
            "device_id" to deviceId,
            "data" to data,
            "timestamp" to System.currentTimeMillis()
        ))
        
        webSocket?.send(message)
    }
    
    /**
     * Disconnect from WebSocket
     */
    fun disconnect() {
        autoReconnect = false
        pingJob?.cancel()
        webSocket?.close(1000, "Client disconnect")
        webSocket = null
        scope?.cancel()
        scope = null
        _isConnected.value = false
        Log.i(TAG, "Disconnected")
    }
    
    // ========== Helpers ==========
    
    private fun parseRoute(json: String): Route? {
        return try {
            gson.fromJson(json, Route::class.java)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to parse route JSON", e)
            null
        }
    }
    
    /**
     * Parse route from a payload map (from WebSocket command)
     */
    fun parseRouteFromPayload(payload: Map<String, Any>?): Route? {
        if (payload == null) return null
        
        return try {
            val waypointsRaw = payload["waypoints"] as? List<*> ?: return null
            val waypoints = waypointsRaw.mapNotNull { wp ->
                val map = wp as? Map<*, *> ?: return@mapNotNull null
                Waypoint(
                    latitude = (map["lat"] as? Number)?.toDouble() ?: return@mapNotNull null,
                    longitude = (map["lng"] as? Number)?.toDouble() ?: return@mapNotNull null,
                    elevation = (map["elevation"] as? Number)?.toDouble(),
                    timestamp = (map["timestamp"] as? Number)?.toLong()
                )
            }
            
            if (waypoints.isEmpty()) return null
            
            Route(
                id = payload["id"] as? String ?: "remote_route",
                name = payload["name"] as? String ?: "Remote Route",
                waypoints = waypoints,
                speedKmh = (payload["speed_kmh"] as? Number)?.toFloat() ?: 30f,
                loop = payload["loop"] as? Boolean ?: false
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to parse route from payload", e)
            null
        }
    }
}
