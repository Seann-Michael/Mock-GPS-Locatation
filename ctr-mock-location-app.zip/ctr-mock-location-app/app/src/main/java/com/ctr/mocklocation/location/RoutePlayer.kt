package com.ctr.mocklocation.location

import android.util.Log
import com.ctr.mocklocation.model.PlaybackState
import com.ctr.mocklocation.model.Route
import com.ctr.mocklocation.model.Waypoint
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.*

/**
 * Plays back a route by sending locations to MockLocationProvider
 */
class RoutePlayer(
    private val mockProvider: MockLocationProvider
) {
    companion object {
        private const val TAG = "RoutePlayer"
        private const val MIN_DELAY_MS = 100L
        private const val DEFAULT_SPEED_KMH = 30f
    }
    
    private var playbackJob: Job? = null
    private var scope: CoroutineScope? = null
    
    private val _state = MutableStateFlow(PlaybackState())
    val state: StateFlow<PlaybackState> = _state.asStateFlow()
    
    // Callbacks
    var onLocationUpdate: ((Waypoint, Int, Int) -> Unit)? = null
    var onRouteComplete: ((Route) -> Unit)? = null
    var onError: ((Exception) -> Unit)? = null
    
    /**
     * Start playing a route
     */
    fun play(route: Route, speedMultiplier: Float = 1.0f) {
        stop()
        
        if (route.waypoints.isEmpty()) {
            Log.w(TAG, "Cannot play empty route")
            return
        }
        
        scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
        
        _state.value = PlaybackState(
            isPlaying = true,
            isPaused = false,
            currentRoute = route,
            currentIndex = 0,
            speedMultiplier = speedMultiplier
        )
        
        playbackJob = scope?.launch {
            try {
                playRoute(route, speedMultiplier)
            } catch (e: CancellationException) {
                Log.d(TAG, "Playback cancelled")
            } catch (e: Exception) {
                Log.e(TAG, "Playback error", e)
                onError?.invoke(e)
            }
        }
        
        Log.i(TAG, "Started playing route: ${route.name} with ${route.waypoints.size} waypoints")
    }
    
    private suspend fun playRoute(route: Route, initialSpeedMultiplier: Float) {
        val waypoints = route.waypoints
        val baseSpeedKmh = route.speedKmh.takeIf { it > 0 } ?: DEFAULT_SPEED_KMH
        var previousWaypoint: Waypoint? = null
        
        var index = 0
        while (index < waypoints.size) {
            if (!isActive) break
            
            // Handle pause
            while (_state.value.isPaused && isActive) {
                delay(100)
            }
            
            val waypoint = waypoints[index]
            val currentSpeedMultiplier = _state.value.speedMultiplier
            
            // Calculate bearing to next point
            val bearing = if (index < waypoints.size - 1) {
                calculateBearing(waypoint, waypoints[index + 1])
            } else {
                previousWaypoint?.let { calculateBearing(it, waypoint) } ?: 0f
            }
            
            // Calculate speed
            val speedMps = calculateSpeed(previousWaypoint, waypoint, baseSpeedKmh)
            
            // Update state
            _state.value = _state.value.copy(
                currentIndex = index,
                currentWaypoint = waypoint
            )
            
            // Set mock location
            mockProvider.setLocation(
                latitude = waypoint.latitude,
                longitude = waypoint.longitude,
                altitude = waypoint.elevation ?: 0.0,
                speed = speedMps,
                bearing = bearing,
                accuracy = 3.0f + (Math.random() * 2).toFloat() // Slight variation
            )
            
            // Callback
            onLocationUpdate?.invoke(waypoint, index, waypoints.size)
            
            // Calculate delay until next waypoint
            if (index < waypoints.size - 1) {
                val nextWaypoint = waypoints[index + 1]
                val delayMs = calculateDelay(waypoint, nextWaypoint, baseSpeedKmh, currentSpeedMultiplier)
                delay(maxOf(delayMs, MIN_DELAY_MS))
            }
            
            previousWaypoint = waypoint
            index++
        }
        
        // Route completed
        if (route.loop && isActive) {
            Log.d(TAG, "Looping route")
            playRoute(route, _state.value.speedMultiplier)
        } else {
            Log.i(TAG, "Route completed: ${route.name}")
            _state.value = _state.value.copy(isPlaying = false)
            onRouteComplete?.invoke(route)
        }
    }
    
    /**
     * Pause playback
     */
    fun pause() {
        _state.value = _state.value.copy(isPaused = true)
        Log.d(TAG, "Playback paused")
    }
    
    /**
     * Resume playback
     */
    fun resume() {
        _state.value = _state.value.copy(isPaused = false)
        Log.d(TAG, "Playback resumed")
    }
    
    /**
     * Stop playback
     */
    fun stop() {
        playbackJob?.cancel()
        playbackJob = null
        scope?.cancel()
        scope = null
        _state.value = PlaybackState()
        Log.d(TAG, "Playback stopped")
    }
    
    /**
     * Set playback speed multiplier
     */
    fun setSpeed(multiplier: Float) {
        _state.value = _state.value.copy(speedMultiplier = multiplier.coerceIn(0.1f, 10f))
        Log.d(TAG, "Speed set to ${multiplier}x")
    }
    
    /**
     * Jump to a specific waypoint index
     */
    fun jumpTo(index: Int) {
        val route = _state.value.currentRoute ?: return
        if (index in route.waypoints.indices) {
            _state.value = _state.value.copy(currentIndex = index)
        }
    }
    
    // ========== Helper Functions ==========
    
    private fun calculateBearing(from: Waypoint, to: Waypoint): Float {
        val lat1 = Math.toRadians(from.latitude)
        val lat2 = Math.toRadians(to.latitude)
        val dLon = Math.toRadians(to.longitude - from.longitude)
        
        val y = sin(dLon) * cos(lat2)
        val x = cos(lat1) * sin(lat2) - sin(lat1) * cos(lat2) * cos(dLon)
        
        return ((Math.toDegrees(atan2(y, x)) + 360) % 360).toFloat()
    }
    
    private fun calculateSpeed(prev: Waypoint?, current: Waypoint, baseSpeedKmh: Float): Float {
        if (prev == null) return baseSpeedKmh * 0.277778f // km/h to m/s
        
        // If timestamps exist, calculate actual speed
        if (prev.timestamp != null && current.timestamp != null && current.timestamp > prev.timestamp) {
            val distanceKm = haversineDistance(prev, current)
            val timeHours = (current.timestamp - prev.timestamp) / 3600000.0
            if (timeHours > 0) {
                return (distanceKm / timeHours * 0.277778).toFloat()
            }
        }
        
        return baseSpeedKmh * 0.277778f
    }
    
    private fun calculateDelay(current: Waypoint, next: Waypoint, baseSpeedKmh: Float, speedMultiplier: Float): Long {
        // If timestamps exist, use them
        if (current.timestamp != null && next.timestamp != null) {
            val timeDiff = next.timestamp - current.timestamp
            return (timeDiff / speedMultiplier).toLong()
        }
        
        // Otherwise calculate based on distance and speed
        val distanceKm = haversineDistance(current, next)
        val timeHours = distanceKm / baseSpeedKmh
        val timeMs = timeHours * 3600 * 1000
        return (timeMs / speedMultiplier).toLong()
    }
    
    private fun haversineDistance(p1: Waypoint, p2: Waypoint): Double {
        val R = 6371.0 // Earth radius in km
        val dLat = Math.toRadians(p2.latitude - p1.latitude)
        val dLon = Math.toRadians(p2.longitude - p1.longitude)
        val a = sin(dLat / 2).pow(2) +
                cos(Math.toRadians(p1.latitude)) * cos(Math.toRadians(p2.latitude)) *
                sin(dLon / 2).pow(2)
        return 2 * R * asin(sqrt(a))
    }
}
