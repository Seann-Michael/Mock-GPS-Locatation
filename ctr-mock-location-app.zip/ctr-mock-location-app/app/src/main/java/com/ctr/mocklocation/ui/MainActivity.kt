package com.ctr.mocklocation.ui

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.method.ScrollingMovementMethod
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.ctr.mocklocation.BuildConfig
import com.ctr.mocklocation.databinding.ActivityMainBinding
import com.ctr.mocklocation.location.MockLocationProvider
import com.ctr.mocklocation.service.MockLocationService
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityMainBinding
    private val dateFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    
    private var isServiceRunning = false
    private var isConnected = false
    
    private val stateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == MockLocationService.BROADCAST_STATE_CHANGED) {
                updateUI(intent)
            }
        }
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        setupUI()
        checkPermissions()
        checkMockLocationEnabled()
    }
    
    private fun setupUI() {
        // Device ID
        val deviceId = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID)
        binding.tvDeviceId.text = "Device ID: $deviceId"
        
        // Server URL
        binding.etServerUrl.setText(BuildConfig.SERVER_URL)
        
        // Log scrolling
        binding.tvLog.movementMethod = ScrollingMovementMethod()
        
        // Start Service button
        binding.btnStartService.setOnClickListener {
            if (!isServiceRunning) {
                startMockService()
            }
        }
        
        // Stop Service button
        binding.btnStopService.setOnClickListener {
            stopMockService()
        }
        
        // Connect button
        binding.btnConnect.setOnClickListener {
            val serverUrl = binding.etServerUrl.text.toString()
            if (serverUrl.isNotBlank()) {
                connectToServer(serverUrl)
            }
        }
        
        log("App started. Device ID: $deviceId")
    }
    
    private fun checkPermissions() {
        val permissions = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        
        val notGranted = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        
        if (notGranted.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, notGranted.toTypedArray(), 1001)
        }
    }
    
    private fun checkMockLocationEnabled() {
        val provider = MockLocationProvider(this)
        if (!provider.isMockLocationEnabled()) {
            log("WARNING: Mock location not enabled for this app")
            Toast.makeText(
                this,
                "Please enable mock location for this app in Developer Settings",
                Toast.LENGTH_LONG
            ).show()
        } else {
            log("Mock location permission OK")
        }
    }
    
    private fun startMockService() {
        log("Starting mock location service...")
        
        val intent = Intent(this, MockLocationService::class.java).apply {
            action = MockLocationService.ACTION_START
        }
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
        
        isServiceRunning = true
        updateButtons()
        log("Service started")
    }
    
    private fun stopMockService() {
        log("Stopping mock location service...")
        
        val intent = Intent(this, MockLocationService::class.java).apply {
            action = MockLocationService.ACTION_STOP
        }
        startService(intent)
        
        isServiceRunning = false
        isConnected = false
        updateButtons()
        updateStatusDisplay()
        log("Service stopped")
    }
    
    private fun connectToServer(serverUrl: String) {
        log("Connecting to server: $serverUrl")
        
        val intent = Intent(this, MockLocationService::class.java).apply {
            action = MockLocationService.ACTION_CONNECT_SERVER
            putExtra(MockLocationService.EXTRA_SERVER_URL, serverUrl)
        }
        startService(intent)
    }
    
    private fun updateUI(intent: Intent) {
        val isPlaying = intent.getBooleanExtra("is_playing", false)
        val isPaused = intent.getBooleanExtra("is_paused", false)
        isConnected = intent.getBooleanExtra("is_connected", false)
        
        val lat = intent.getDoubleExtra("latitude", Double.NaN)
        val lng = intent.getDoubleExtra("longitude", Double.NaN)
        val progress = intent.getFloatExtra("progress", 0f)
        val routeName = intent.getStringExtra("route_name")
        val routeSize = intent.getIntExtra("route_size", 0)
        val currentIndex = intent.getIntExtra("current_index", 0)
        
        // Update location display
        if (!lat.isNaN() && !lng.isNaN()) {
            binding.tvLatitude.text = "Lat: ${"%.7f".format(lat)}"
            binding.tvLongitude.text = "Lng: ${"%.7f".format(lng)}"
        }
        
        // Update progress
        if (routeSize > 0) {
            binding.tvProgress.text = "Progress: ${currentIndex + 1}/$routeSize (${"%.1f".format(progress * 100)}%)"
        }
        
        // Update playback status
        binding.tvPlaybackStatus.text = when {
            isPaused -> "Paused"
            isPlaying -> "Playing: $routeName"
            else -> "Idle"
        }
        binding.tvPlaybackStatus.setTextColor(
            ContextCompat.getColor(this, when {
                isPaused -> com.ctr.mocklocation.R.color.status_paused
                isPlaying -> com.ctr.mocklocation.R.color.status_playing
                else -> android.R.color.darker_gray
            })
        )
        
        updateStatusDisplay()
    }
    
    private fun updateStatusDisplay() {
        // Service status
        binding.tvServiceStatus.text = if (isServiceRunning) "Running" else "Stopped"
        binding.tvServiceStatus.setTextColor(
            ContextCompat.getColor(this, 
                if (isServiceRunning) com.ctr.mocklocation.R.color.status_connected 
                else com.ctr.mocklocation.R.color.status_disconnected
            )
        )
        
        // Server status
        binding.tvServerStatus.text = if (isConnected) "Connected" else "Disconnected"
        binding.tvServerStatus.setTextColor(
            ContextCompat.getColor(this,
                if (isConnected) com.ctr.mocklocation.R.color.status_connected
                else com.ctr.mocklocation.R.color.status_disconnected
            )
        )
    }
    
    private fun updateButtons() {
        binding.btnStartService.isEnabled = !isServiceRunning
        binding.btnConnect.isEnabled = isServiceRunning
        binding.btnStopService.isEnabled = isServiceRunning
    }
    
    private fun log(message: String) {
        val timestamp = dateFormat.format(Date())
        val logLine = "[$timestamp] $message\n"
        
        runOnUiThread {
            binding.tvLog.append(logLine)
            // Auto-scroll to bottom
            val scrollAmount = binding.tvLog.layout?.let {
                it.getLineTop(binding.tvLog.lineCount) - binding.tvLog.height
            } ?: 0
            if (scrollAmount > 0) {
                binding.tvLog.scrollTo(0, scrollAmount)
            }
        }
    }
    
    override fun onResume() {
        super.onResume()
        val filter = IntentFilter(MockLocationService.BROADCAST_STATE_CHANGED)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(stateReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(stateReceiver, filter)
        }
    }
    
    override fun onPause() {
        super.onPause()
        try {
            unregisterReceiver(stateReceiver)
        } catch (e: Exception) {
            // Ignore
        }
    }
}
