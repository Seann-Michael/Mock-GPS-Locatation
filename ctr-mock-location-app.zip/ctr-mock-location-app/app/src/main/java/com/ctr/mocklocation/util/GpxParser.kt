package com.ctr.mocklocation.util

import android.util.Log
import android.util.Xml
import com.ctr.mocklocation.model.Route
import com.ctr.mocklocation.model.Waypoint
import org.xmlpull.v1.XmlPullParser
import java.io.File
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.*

/**
 * Parser for GPX (GPS Exchange Format) files
 */
object GpxParser {
    
    private const val TAG = "GpxParser"
    
    private val dateFormats = listOf(
        SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") },
        SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ", Locale.US),
        SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") },
        SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US)
    )
    
    /**
     * Parse a GPX file from path
     */
    fun parseFile(filePath: String): Route? {
        return try {
            val file = File(filePath)
            if (!file.exists()) {
                Log.e(TAG, "File not found: $filePath")
                return null
            }
            file.inputStream().use { parseStream(it, file.nameWithoutExtension) }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to parse GPX file: $filePath", e)
            null
        }
    }
    
    /**
     * Parse GPX from input stream
     */
    fun parseStream(inputStream: InputStream, name: String = "Imported Route"): Route? {
        return try {
            val parser = Xml.newPullParser()
            parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
            parser.setInput(inputStream, null)
            
            val waypoints = mutableListOf<Waypoint>()
            var routeName = name
            
            var eventType = parser.eventType
            var currentLat: Double? = null
            var currentLon: Double? = null
            var currentEle: Double? = null
            var currentTime: Long? = null
            var currentName: String? = null
            var inTrackPoint = false
            var inWaypoint = false
            
            while (eventType != XmlPullParser.END_DOCUMENT) {
                when (eventType) {
                    XmlPullParser.START_TAG -> {
                        when (parser.name.lowercase()) {
                            "trkpt", "rtept" -> {
                                inTrackPoint = true
                                currentLat = parser.getAttributeValue(null, "lat")?.toDoubleOrNull()
                                currentLon = parser.getAttributeValue(null, "lon")?.toDoubleOrNull()
                            }
                            "wpt" -> {
                                inWaypoint = true
                                currentLat = parser.getAttributeValue(null, "lat")?.toDoubleOrNull()
                                currentLon = parser.getAttributeValue(null, "lon")?.toDoubleOrNull()
                            }
                            "ele" -> {
                                if (inTrackPoint || inWaypoint) {
                                    currentEle = parser.nextText()?.toDoubleOrNull()
                                }
                            }
                            "time" -> {
                                if (inTrackPoint || inWaypoint) {
                                    currentTime = parseTime(parser.nextText())
                                }
                            }
                            "name" -> {
                                val text = parser.nextText()
                                if (inTrackPoint || inWaypoint) {
                                    currentName = text
                                } else {
                                    // Track or route name
                                    if (text.isNotBlank()) routeName = text
                                }
                            }
                        }
                    }
                    XmlPullParser.END_TAG -> {
                        when (parser.name.lowercase()) {
                            "trkpt", "rtept", "wpt" -> {
                                if (currentLat != null && currentLon != null) {
                                    waypoints.add(
                                        Waypoint(
                                            latitude = currentLat,
                                            longitude = currentLon,
                                            elevation = currentEle,
                                            timestamp = currentTime,
                                            name = currentName
                                        )
                                    )
                                }
                                // Reset
                                currentLat = null
                                currentLon = null
                                currentEle = null
                                currentTime = null
                                currentName = null
                                inTrackPoint = false
                                inWaypoint = false
                            }
                        }
                    }
                }
                eventType = parser.next()
            }
            
            if (waypoints.isEmpty()) {
                Log.w(TAG, "No waypoints found in GPX")
                return null
            }
            
            Log.i(TAG, "Parsed ${waypoints.size} waypoints from GPX: $routeName")
            
            Route(
                id = UUID.randomUUID().toString(),
                name = routeName,
                waypoints = waypoints
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to parse GPX stream", e)
            null
        }
    }
    
    /**
     * Parse GPX from string content
     */
    fun parseString(gpxContent: String, name: String = "Imported Route"): Route? {
        return gpxContent.byteInputStream().use { parseStream(it, name) }
    }
    
    private fun parseTime(timeStr: String?): Long? {
        if (timeStr.isNullOrBlank()) return null
        
        for (format in dateFormats) {
            try {
                return format.parse(timeStr)?.time
            } catch (e: Exception) {
                // Try next format
            }
        }
        
        Log.w(TAG, "Could not parse time: $timeStr")
        return null
    }
}
