package com.ctr.mocklocation

import android.app.Application
import android.util.Log

class CTRApplication : Application() {
    
    companion object {
        private const val TAG = "CTRApplication"
    }
    
    override fun onCreate() {
        super.onCreate()
        Log.i(TAG, "CTR Mock Location App initialized")
    }
}
