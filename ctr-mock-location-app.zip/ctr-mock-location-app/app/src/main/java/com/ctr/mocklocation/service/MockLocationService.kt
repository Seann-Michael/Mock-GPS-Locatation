package com.ctr.mocklocation.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.provider.Settings
import android.util.Log
import androidx.core.app.NotificationCompat
import com.ctr.mocklocation.BuildConfig
import com.ctr.mocklocation.R
import com.ctr.mocklocation.api.ApiClient
import com.ctr.mocklocation.location.MockLocationProvider
import com.ctr.mocklocation.location.RoutePlayer
import com.ctr.mocklocation.model.*
import com.ctr.mocklocation.ui.MainActivity
import com.ctr.mocklocation.util.GpxParser
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.collectLatest

/**
 * Foreground service that manages mock location playback
 */
class MockLocationService : Service() {
    
    companion object {
        private const val TAG = "MockLocationService"
        private const val CHANNEL_ID = "mock_location_channel"
        private const val NOTIFICATION_ID = 1001
        
        // Intent actions (can be triggered via ADB)
        const val ACTION_START = "com.ctr.mocklocation.START"
        const val ACTION_STOP = "com.ctr.mocklocation.STOP"
        const val ACTION_LOAD_ROUTE = "com.ctr.mocklocation.LOAD_ROUTE"
        const val ACTION_LOAD_GPX = "com.ctr.mocklocation.LOAD_GPX"
        const val ACTION_SET_LOCATION = "com.ctr.mocklocation.SET_LOCATION"
        const val ACTION_PAUSE = "com.ctr.mocklocation.PAUSE"
        const val ACTION_RESUME = "com.ctr.mocklocation.RESUME"
        const val ACTION_SET_SPEED = "com.ctr.mocklocation.SET_SPEED"
        const val ACTION_CONNECT_SERVER = "com.ctr.mocklocation.CONNECT_SERVER"
        
        // Intent extras
        const val EXTRA_ROUTE_ID = "route_id"
        const val EXTRA_GPX_PATH = "gpx_path"
        const val EXTRA_GPX_CONTENT = "gpx_content"
        const val EXTRA_LATITUDE = "latitude"
        const val EXTRA_LONGITUDE = "longitude"
        const val EXTRA_ALTITUDE = "altitude"
        const val EXTRA_SPEED = "speed"
        const val EXTRA_SERVER_URL = "server_url"
        const val EXTRA_WAYPOINTS_JSON = "waypoints_json"
        
        // Service state broadcast
        const val BROADCAST_STATE_CHANGED = "com.ctr.mocklocation.STATE_CHANGED"
    }
    
    private lateinit var mockProvider: MockLocationProvider
    private lateinit var routePlayer: RoutePlayer
    private lateinit var apiClient: ApiClient
    private lateinit var deviceId: String
    
    private val serviceScope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var wakeLock: PowerManager.WakeLock? = null
    
    override fun onCreate() {
        super.onCreate()
        Log.i(TAG, "Service created")
        
        // Get device ID
        deviceId = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID)
        
        // Initialize components
        mockProvider = MockLocationProvider(this)
        routePlayer = RoutePlayer(mockProvider)
        apiClient = ApiClient(BuildConfig.SERVER_URL, deviceId)
        
        // Setup route player callbacks
        setupRoutePlayerCallbacks()
        
        // Setup API client callbacks
        setupApiClientCallbacks()
        
        // Create notification channel
        createNotificationChannel()
        
        // Acquire wake lock to prevent CPU sleep
        acquireWakeLock()
    }
    
    private fun setupRoutePlayerCallbacks() {
        routePlayer.onLocationUpdate = { waypoint, index, total ->
            // Send status update
            val state = routePlayer.state.value
            apiClient.sendStatus(DeviceStatus(
                deviceId = deviceId,
                status = DeviceStatus.STATUS_PLAYING,
                latitude = waypoint.latitude,
                longitude = waypoint.longitude,
                speed = state.speedMultiplier * 30f, // Approximate
                routeId = state.currentRoute?.id,
                progress = index.toFloat() / total
            ))
            
            // Update notification
            updateNotification("Playing: ${index + 1}/$total")
            
            // Broadcast state change
            broadcastState()
        }
        
        routePlayer.onRouteComplete = { route ->
            Log.i(TAG, "Route completed: ${route.name}")
            apiClient.sendStatus(DeviceStatus(
                deviceId = deviceId,
                status = DeviceStatus.STATUS_COMPLETED,
                latitude = null,
                longitude = null,
                speed = null,
                routeId = route.id,
                progress = 1f
            ))
            updateNotification("Route completed")
            broadcastState()
        }
    }
    
    private fun setupApiClientCallbacks() {
        // Collect commands from server
        serviceScope.launch {
            apiClient.commands.collectLatest { command ->
                handleServerCommand(command)
            }
        }
        
        apiClient.onConnected = {
            Log.i(TAG, "Connected to server")
            updateNotification("Connected to server")
            broadcastState()
        }
        
        apiClient.onDisconnected = {
            Log.w(TAG, "Disconnected from server")
            updateNotification("Disconnected from server")
            broadcastState()
        }
    }
    
    private fun handleServerCommand(command: ServerCommand) {
        Log.d(TAG, "Received command: ${command.type}")
        
        when (command.type) {
            ServerCommand.TYPE_LOAD_ROUTE -> {
                val route = apiClient.parseRouteFromPayload(command.payload)
                if (route != null) {
                    val speed = (command.payload?.get("speed") as? Number)?.toFloat() ?: 1f
                    routePlayer.play(route, speed)
                }
            }
            ServerCommand.TYPE_START -> {
                routePlayer.state.value.currentRoute?.let {
                    routePlayer.resume()
                }
            }
            ServerCommand.TYPE_STOP -> {
                routePlayer.stop()
            }
            ServerCommand.TYPE_PAUSE -> {
                routePlayer.pause()
            }
            ServerCommand.TYPE_RESUME -> {
                routePlayer.resume()
            }
            ServerCommand.TYPE_SET_SPEED -> {
                val speed = (command.payload?.get("speed") as? Number)?.toFloat() ?: 1f
                routePlayer.setSpeed(speed)
            }
            ServerCommand.TYPE_SET_LOCATION -> {
                val lat = (command.payload?.get("lat") as? Number)?.toDouble()
                val lng = (command.payload?.get("lng") as? Number)?.toDouble()
                if (lat != null && lng != null) {
                    routePlayer.stop()
                    mockProvider.setLocation(lat, lng)
                }
            }
            ServerCommand.TYPE_PING -> {
                apiClient.sendMessage("pong")
            }
        }
    }
    
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d(TAG, "onStartCommand: ${intent?.action}")
        
        // Start as foreground service
        startForeground(NOTIFICATION_ID, createNotification("Initializing..."))
        
        // Initialize mock provider
        if (!mockProvider.initialize()) {
            Log.e(TAG, "Failed to initialize mock location provider")
            updateNotification("Error: Mock location not enabled")
            // Don't stop - user might enable it later
        }
        
        // Handle intent action
        when (intent?.action) {
            ACTION_START, null -> {
                updateNotification("Ready")
                apiClient.sendStatus(DeviceStatus(
                    deviceId = deviceId,
                    status = DeviceStatus.STATUS_IDLE,
                    latitude = null, longitude = null, speed = null,
                    routeId = null, progress = null
                ))
            }
            
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            
            ACTION_LOAD_ROUTE -> {
                handleLoadRoute(intent)
            }
            
            ACTION_LOAD_GPX -> {
                handleLoadGpx(intent)
            }
            
            ACTION_SET_LOCATION -> {
                handleSetLocation(intent)
            }
            
            ACTION_PAUSE -> {
                routePlayer.pause()
                updateNotification("Paused")
            }
            
            ACTION_RESUME -> {
                routePlayer.resume()
            }
            
            ACTION_SET_SPEED -> {
                val speed = intent.getFloatExtra(EXTRA_SPEED, 1f)
                routePlayer.setSpeed(speed)
            }
            
            ACTION_CONNECT_SERVER -> {
                val serverUrl = intent.getStringExtra(EXTRA_SERVER_URL)
                if (serverUrl != null) {
                    apiClient.setServerUrl(serverUrl)
                }
                apiClient.connect()
            }
        }
        
        broadcastState()
        return START_STICKY
    }
    
    private fun handleLoadRoute(intent: Intent) {
        val routeId = intent.getStringExtra(EXTRA_ROUTE_ID)
        val waypointsJson = intent.getStringExtra(EXTRA_WAYPOINTS_JSON)
        val speed = intent.getFloatExtra(EXTRA_SPEED, 1f)
        
        serviceScope.launch {
            val route = when {
                // Load from waypoints JSON
                waypointsJson != null -> {
                    try {
                        val waypoints = parseWaypointsJson(waypointsJson)
                        Route(
                            id = "local_route",
                            name = "Local Route",
                            waypoints = waypoints
                        )
                    } catch (e: Exception) {
                        Log.e(TAG, "Failed to parse waypoints JSON", e)
                        null
                    }
                }
                // Load from server
                routeId != null -> {
                    apiClient.fetchRoute(routeId)
                }
                else -> null
            }
            
            if (route != null) {
                routePlayer.play(route, speed)
                updateNotification("Playing: ${route.name}")
            } else {
                updateNotification("Failed to load route")
            }
        }
    }
    
    private fun handleLoadGpx(intent: Intent) {
        val gpxPath = intent.getStringExtra(EXTRA_GPX_PATH)
        val gpxContent = intent.getStringExtra(EXTRA_GPX_CONTENT)
        val speed = intent.getFloatExtra(EXTRA_SPEED, 1f)
        
        val route = when {
            gpxPath != null -> GpxParser.parseFile(gpxPath)
            gpxContent != null -> GpxParser.parseString(gpxContent)
            else -> null
        }
        
        if (route != null) {
            routePlayer.play(route, speed)
            updateNotification("Playing: ${route.name}")
        } else {
            updateNotification("Failed to parse GPX")
        }
    }
    
    private fun handleSetLocation(intent: Intent) {
        val lat = intent.getDoubleExtra(EXTRA_LATITUDE, Double.NaN)
        val lng = intent.getDoubleExtra(EXTRA_LONGITUDE, Double.NaN)
        val alt = intent.getDoubleExtra(EXTRA_ALTITUDE, 0.0)
        
        if (!lat.isNaN() && !lng.isNaN()) {
            routePlayer.stop()
            mockProvider.setLocation(lat, lng, alt)
            updateNotification("Static: ${"%.5f".format(lat)}, ${"%.5f".format(lng)}")
        }
    }
    
    private fun parseWaypointsJson(json: String): List<Waypoint> {
        val gson = com.google.gson.Gson()
        val type = object : com.google.gson.reflect.TypeToken<List<Map<String, Any>>>() {}.type
        val list: List<Map<String, Any>> = gson.fromJson(json, type)
        
        return list.mapNotNull { map ->
            val lat = (map["lat"] as? Number)?.toDouble() ?: return@mapNotNull null
            val lng = (map["lng"] as? Number)?.toDouble() ?: return@mapNotNull null
            Waypoint(
                latitude = lat,
                longitude = lng,
                elevation = (map["elevation"] as? Number)?.toDouble(),
                timestamp = (map["timestamp"] as? Number)?.toLong()
            )
        }
    }
    
    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.channel_name),
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = getString(R.string.channel_description)
            setShowBadge(false)
        }
        
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }
    
    private fun createNotification(status: String): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, MockLocationService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(status)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentIntent(pendingIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stopIntent)
            .setOngoing(true)
            .setSilent(true)
            .build()
    }
    
    private fun updateNotification(status: String) {
        val notification = createNotification(status)
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification)
    }
    
    private fun broadcastState() {
        val intent = Intent(BROADCAST_STATE_CHANGED).apply {
            val state = routePlayer.state.value
            putExtra("is_playing", state.isPlaying)
            putExtra("is_paused", state.isPaused)
            putExtra("current_index", state.currentIndex)
            putExtra("progress", state.progress)
            putExtra("is_connected", apiClient.isConnected.value)
            state.currentWaypoint?.let {
                putExtra("latitude", it.latitude)
                putExtra("longitude", it.longitude)
            }
            state.currentRoute?.let {
                putExtra("route_name", it.name)
                putExtra("route_size", it.waypoints.size)
            }
        }
        sendBroadcast(intent)
    }
    
    private fun acquireWakeLock() {
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "CTRMockLocation::ServiceWakeLock"
        ).apply {
            acquire(10 * 60 * 60 * 1000L) // 10 hours max
        }
    }
    
    override fun onDestroy() {
        Log.i(TAG, "Service destroyed")
        
        routePlayer.stop()
        mockProvider.cleanup()
        apiClient.disconnect()
        serviceScope.cancel()
        wakeLock?.release()
        
        super.onDestroy()
    }
    
    override fun onBind(intent: Intent?): IBinder? = null
}
