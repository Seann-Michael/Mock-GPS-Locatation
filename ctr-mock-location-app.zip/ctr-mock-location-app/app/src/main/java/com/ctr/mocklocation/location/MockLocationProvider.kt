package com.ctr.mocklocation.location

import android.content.Context
import android.location.Criteria
import android.location.Location
import android.location.LocationManager
import android.location.provider.ProviderProperties
import android.os.Build
import android.os.SystemClock
import android.util.Log

/**
 * Handles mock location provider setup and location injection
 */
class MockLocationProvider(private val context: Context) {
    
    companion object {
        private const val TAG = "MockLocationProvider"
    }
    
    private val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    
    private val providers = listOf(
        LocationManager.GPS_PROVIDER,
        LocationManager.NETWORK_PROVIDER
    )
    
    private var isInitialized = false
    
    /**
     * Initialize mock location providers
     * @return true if successful, false if mock location permission not granted
     */
    fun initialize(): Boolean {
        if (isInitialized) return true
        
        return try {
            for (provider in providers) {
                setupProvider(provider)
            }
            isInitialized = true
            Log.i(TAG, "Mock location providers initialized successfully")
            true
        } catch (e: SecurityException) {
            Log.e(TAG, "Mock location permission not granted", e)
            false
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize mock location providers", e)
            false
        }
    }
    
    private fun setupProvider(providerName: String) {
        // Remove existing test provider if any
        try {
            locationManager.removeTestProvider(providerName)
        } catch (e: Exception) {
            // Ignore - provider might not exist
        }
        
        // Add test provider with appropriate properties
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            locationManager.addTestProvider(
                providerName,
                false, // requiresNetwork
                false, // requiresSatellite
                false, // requiresCell
                false, // hasMonetaryCost
                true,  // supportsAltitude
                true,  // supportsSpeed
                true,  // supportsBearing
                ProviderProperties.POWER_USAGE_LOW,
                ProviderProperties.ACCURACY_FINE
            )
        } else {
            @Suppress("DEPRECATION")
            locationManager.addTestProvider(
                providerName,
                false, // requiresNetwork
                false, // requiresSatellite
                false, // requiresCell
                false, // hasMonetaryCost
                true,  // supportsAltitude
                true,  // supportsSpeed
                true,  // supportsBearing
                Criteria.POWER_LOW,
                Criteria.ACCURACY_FINE
            )
        }
        
        locationManager.setTestProviderEnabled(providerName, true)
        Log.d(TAG, "Test provider $providerName enabled")
    }
    
    /**
     * Set a mock location
     */
    fun setLocation(
        latitude: Double,
        longitude: Double,
        altitude: Double = 0.0,
        accuracy: Float = 3.0f,
        speed: Float = 0.0f,
        bearing: Float = 0.0f,
        time: Long = System.currentTimeMillis()
    ) {
        if (!isInitialized) {
            Log.w(TAG, "Provider not initialized, attempting to initialize...")
            if (!initialize()) {
                Log.e(TAG, "Failed to initialize provider")
                return
            }
        }
        
        for (provider in providers) {
            try {
                val location = createLocation(provider, latitude, longitude, altitude, accuracy, speed, bearing, time)
                locationManager.setTestProviderLocation(provider, location)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to set location for $provider", e)
            }
        }
    }
    
    private fun createLocation(
        provider: String,
        latitude: Double,
        longitude: Double,
        altitude: Double,
        accuracy: Float,
        speed: Float,
        bearing: Float,
        time: Long
    ): Location {
        return Location(provider).apply {
            this.latitude = latitude
            this.longitude = longitude
            this.altitude = altitude
            this.accuracy = accuracy
            this.speed = speed
            this.bearing = bearing
            this.time = time
            this.elapsedRealtimeNanos = SystemClock.elapsedRealtimeNanos()
            
            // Set additional fields for better compatibility
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                bearingAccuracyDegrees = 5.0f
                speedAccuracyMetersPerSecond = 0.5f
                verticalAccuracyMeters = 10.0f
            }
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                elapsedRealtimeUncertaintyNanos = 1000.0
            }
        }
    }
    
    /**
     * Clean up mock location providers
     */
    fun cleanup() {
        for (provider in providers) {
            try {
                locationManager.setTestProviderEnabled(provider, false)
                locationManager.removeTestProvider(provider)
                Log.d(TAG, "Test provider $provider removed")
            } catch (e: Exception) {
                // Ignore cleanup errors
            }
        }
        isInitialized = false
        Log.i(TAG, "Mock location providers cleaned up")
    }
    
    /**
     * Check if mock location is properly configured
     */
    fun isMockLocationEnabled(): Boolean {
        return try {
            // Try to add and immediately remove a test provider
            val testProvider = "test_provider_check"
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                locationManager.addTestProvider(
                    testProvider, false, false, false, false, true, true, true,
                    ProviderProperties.POWER_USAGE_LOW, ProviderProperties.ACCURACY_FINE
                )
            } else {
                @Suppress("DEPRECATION")
                locationManager.addTestProvider(
                    testProvider, false, false, false, false, true, true, true,
                    Criteria.POWER_LOW, Criteria.ACCURACY_FINE
                )
            }
            locationManager.removeTestProvider(testProvider)
            true
        } catch (e: SecurityException) {
            false
        }
    }
}
