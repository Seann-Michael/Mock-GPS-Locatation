# CTR Mock Location Android App

A custom Android app for mock location testing with API-based route control. Built for fleet management of 200+ devices.

## Features

- **Mock Location Provider** - Injects GPS and Network locations
- **Route Playback** - Plays back GPX routes with realistic timing
- **API Integration** - REST API for route fetching, WebSocket for real-time control
- **ADB Control** - Full control via ADB commands (no UI needed)
- **Auto-reconnect** - Automatically reconnects to server
- **Boot Start** - Optionally starts on device boot

## Setup

### Prerequisites

1. Enable Developer Options on your Android device
2. Enable "Mock Location App" and select this app
3. Grant location permissions

### Building

```bash
# Clone the project
git clone https://github.com/Seann-Michael/Mock-GPS-Locatation.git
cd Mock-GPS-Locatation

# Build debug APK
./gradlew assembleDebug

# Build release APK
./gradlew assembleRelease

# APK location: app/build/outputs/apk/debug/app-debug.apk
```

### Installation

```bash
# Install APK
adb install -r app/build/outputs/apk/debug/app-debug.apk

# Enable mock location permission
adb shell appops set com.ctr.mocklocation android:mock_location allow

# Grant location permissions
adb shell pm grant com.ctr.mocklocation android.permission.ACCESS_FINE_LOCATION
adb shell pm grant com.ctr.mocklocation android.permission.ACCESS_COARSE_LOCATION
```

## ADB Commands

The app can be fully controlled via ADB without using the UI. This is ideal for fleet automation.

### Start/Stop Service

```bash
# Start the mock location service
adb shell am startservice -n com.ctr.mocklocation/.service.MockLocationService -a com.ctr.mocklocation.START

# Stop the service
adb shell am startservice -n com.ctr.mocklocation/.service.MockLocationService -a com.ctr.mocklocation.STOP
```

### Set Static Location

```bash
# Set a single location (stops any route playback)
adb shell am startservice -n com.ctr.mocklocation/.service.MockLocationService \
  -a com.ctr.mocklocation.SET_LOCATION \
  --ef latitude 41.1234 \
  --ef longitude -81.5678 \
  --ef altitude 250.0
```

### Load and Play GPX File

```bash
# Push GPX file to device
adb push route.gpx /sdcard/Download/route.gpx

# Load and play the GPX file
adb shell am startservice -n com.ctr.mocklocation/.service.MockLocationService \
  -a com.ctr.mocklocation.LOAD_GPX \
  --es gpx_path "/sdcard/Download/route.gpx" \
  --ef speed 1.5
```

### Load Route from JSON Waypoints

```bash
# Load route from inline JSON waypoints
adb shell am startservice -n com.ctr.mocklocation/.service.MockLocationService \
  -a com.ctr.mocklocation.LOAD_ROUTE \
  --es waypoints_json '[{"lat":41.1234,"lng":-81.5678},{"lat":41.1240,"lng":-81.5670}]' \
  --ef speed 1.0
```

### Playback Controls

```bash
# Pause playback
adb shell am startservice -n com.ctr.mocklocation/.service.MockLocationService \
  -a com.ctr.mocklocation.PAUSE

# Resume playback
adb shell am startservice -n com.ctr.mocklocation/.service.MockLocationService \
  -a com.ctr.mocklocation.RESUME

# Set playback speed (1.0 = normal, 2.0 = 2x speed)
adb shell am startservice -n com.ctr.mocklocation/.service.MockLocationService \
  -a com.ctr.mocklocation.SET_SPEED \
  --ef speed 2.0
```

### Connect to Server

```bash
# Connect to control server for remote commands
adb shell am startservice -n com.ctr.mocklocation/.service.MockLocationService \
  -a com.ctr.mocklocation.CONNECT_SERVER \
  --es server_url "http://your-server.com:8080"
```

### Fetch Route from Server

```bash
# Fetch and play a route by ID from the server
adb shell am startservice -n com.ctr.mocklocation/.service.MockLocationService \
  -a com.ctr.mocklocation.LOAD_ROUTE \
  --es route_id "route_123" \
  --ef speed 1.0
```

## Server API

The app expects a server with the following endpoints:

### REST Endpoints

```
GET  /api/routes/{route_id}     - Fetch a route by ID
POST /api/devices/status        - Receive device status updates
POST /api/devices/register      - Register a new device
GET  /api/devices               - List all devices
```

### WebSocket

```
WS /api/ws/{device_id}          - Real-time command channel
```

### Route JSON Format

```json
{
  "id": "route_123",
  "name": "Test Route",
  "waypoints": [
    {"lat": 41.1234, "lng": -81.5678, "elevation": 250, "timestamp": 1705320000000},
    {"lat": 41.1240, "lng": -81.5670, "elevation": 252, "timestamp": 1705320005000}
  ],
  "speed_kmh": 30,
  "loop": false
}
```

### Server Commands (via WebSocket)

```json
// Load a route
{"type": "load_route", "payload": {"id": "...", "name": "...", "waypoints": [...]}}

// Control playback
{"type": "start"}
{"type": "stop"}
{"type": "pause"}
{"type": "resume"}

// Set speed multiplier
{"type": "set_speed", "payload": {"speed": 2.0}}

// Set static location
{"type": "set_location", "payload": {"lat": 41.1234, "lng": -81.5678}}
```

### Device Status Updates

The app sends status updates to the server:

```json
{
  "device_id": "abc123",
  "status": "playing",
  "latitude": 41.1234,
  "longitude": -81.5678,
  "speed": 30.0,
  "route_id": "route_123",
  "progress": 0.45,
  "timestamp": 1705320000000
}
```

Status values: `idle`, `playing`, `paused`, `completed`, `error`

## Fleet Management

### Setup Script for Multiple Devices

```bash
#!/bin/bash
# setup_fleet.sh

APK_PATH="./app-debug.apk"
SERVER_URL="http://your-server.com:8080"

# Get all connected devices
for DEVICE in $(adb devices | grep -v "List" | grep "device$" | cut -f1); do
    echo "Setting up device: $DEVICE"
    
    # Install APK
    adb -s $DEVICE install -r $APK_PATH
    
    # Enable mock location
    adb -s $DEVICE shell appops set com.ctr.mocklocation android:mock_location allow
    
    # Grant permissions
    adb -s $DEVICE shell pm grant com.ctr.mocklocation android.permission.ACCESS_FINE_LOCATION
    adb -s $DEVICE shell pm grant com.ctr.mocklocation android.permission.ACCESS_COARSE_LOCATION
    
    # Start service and connect to server
    adb -s $DEVICE shell am startservice \
        -n com.ctr.mocklocation/.service.MockLocationService \
        -a com.ctr.mocklocation.START
    
    adb -s $DEVICE shell am startservice \
        -n com.ctr.mocklocation/.service.MockLocationService \
        -a com.ctr.mocklocation.CONNECT_SERVER \
        --es server_url "$SERVER_URL"
    
    echo "Device $DEVICE configured"
done
```

### Broadcast Command to All Devices

```bash
#!/bin/bash
# broadcast_route.sh

GPX_FILE=$1
SPEED=${2:-1.0}

for DEVICE in $(adb devices | grep -v "List" | grep "device$" | cut -f1); do
    adb -s $DEVICE push $GPX_FILE /sdcard/Download/route.gpx
    adb -s $DEVICE shell am startservice \
        -n com.ctr.mocklocation/.service.MockLocationService \
        -a com.ctr.mocklocation.LOAD_GPX \
        --es gpx_path "/sdcard/Download/route.gpx" \
        --ef speed $SPEED &
done
wait
echo "Route deployed to all devices"
```

## GPX File Format

Standard GPX 1.1 format is supported:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<gpx version="1.1" creator="YourApp">
  <trk>
    <name>My Route</name>
    <trkseg>
      <trkpt lat="41.1234" lon="-81.5678">
        <ele>250.5</ele>
        <time>2024-01-15T10:00:00Z</time>
      </trkpt>
      <trkpt lat="41.1240" lon="-81.5670">
        <ele>252.0</ele>
        <time>2024-01-15T10:00:05Z</time>
      </trkpt>
    </trkseg>
  </trk>
</gpx>
```

## Configuration

Edit `app/build.gradle` to change the default server URL:

```gradle
buildConfigField "String", "SERVER_URL", '"http://your-server.com:8080"'
```

## Troubleshooting

### Mock Location Not Working

1. Ensure Developer Options are enabled
2. Go to Developer Options → Select mock location app → Choose "CTR Mock Location"
3. Run: `adb shell appops set com.ctr.mocklocation android:mock_location allow`

### Service Keeps Stopping

1. Disable battery optimization for the app
2. Lock the app in recent apps (if supported by device)

### Location Not Updating in Other Apps

Some apps detect mock locations. The app sets all required fields to appear as real GPS data, but some apps may still detect it.

## License

MIT License - Use freely for your CTR testing project.
